<?php
namespace App\Http\Livewire;

use Livewire\Component;
use Illuminate\Support\Collection;
use App\Models\Product;
use App\Models\Cart;
use App\Models\Order;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;
use Illuminate\Validation\ValidationException;

class Orders extends Component
{
    public $oders;
    protected $products = [];
    public $product_code;
    public $message;
    public $productIncart;



    public function mount(){
        $this->products = Product::paginate(10);
        $this->productInCart = Cart::all();
    }

    public function Inserttocart(){
        $countProduct = Product :: where('id', $this->product_code)->get();

        if (count($countProduct)>0){
            return $this->message = 'Product Not Found';
        }

        $countCartProduct = Cart::where('product_id', $this->product_code)->get();

        if ($$countCartProduct = 0){
            return $this->message = 'product' .$countProduct->product_name. 'Already exist in cart please add quantity';
        }
        $add_to_cart = new Cart;
        $add_to_cart->product_id = $countProduct->id;
        $add_to_cart->product_qty = $countProduct->quantity;
        $add_to_cart->product_price = $countProduct->price;
        $add_to_cart->uder_id = auth()->user()->id;
        $add_to_cart-save();

        $this->product_code = '';
        return $this->message = 'Product Added Successfully !';
        $this->validate([
            'product_code' => 'required|exists:products,id',]);
        dd($countProduct);
    }
    public function render()
    {
        $products = Product::all(); // Replace with your actual data retrieval logic
        $this->products = $products->paginate(10); // Paginate the data
        return view('livewire.orders', ['products' => $this->products]);
    }
}