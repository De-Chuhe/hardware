<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Product extends Model
{
  protected $table ='products';
  protected $fillable = ['product_name','price','alert_stock','quantity','brand','description'];

    public function order_Detail()
    {
       return $this->hasMany('App\Order_Detail');
    }

}
