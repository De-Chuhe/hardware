<?php

// app/Models/Order.php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Order extends Model
{

    public function order_Detail()
    {
       return $this->hasMany(Order_Detail::class, 'order_id');
    }
}
