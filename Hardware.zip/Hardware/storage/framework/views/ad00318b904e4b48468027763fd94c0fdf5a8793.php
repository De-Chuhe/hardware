<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-lg-8">
            <div class="card">
                <div class="card-header">
                    <h4 style="float:left">Add Products</h4>
                    <a href="#" style="float:right" class="btn btn-dark" data-toggle="modal" data-target="#addproduct">
                        <i class="fa fa-plus"></i> Add New Products
                    </a>
                </div>
                <div class="card-body">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Product Name</th>
                                <th>Brand</th>
                                <th>Price</th>
                                <th>Quantity</th>
                                <th>Alert_stock</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($key + 1); ?></td>
                                    <td><?php echo e($product->product_name); ?></td>
                                    <td><?php echo e($product->brand); ?></td>
                                    <td><?php echo e(number_format($product->price,2)); ?></td>
                                    <td><?php echo e($product->quantity); ?></td>
                                    <td>
                                    <?php
                                        $alertStock = $product->alert_stock ?? 0;
                                        $quantity = $product->quantity ?? 0;
                                    ?>
                                        <?php if($alertStock >= $quantity): ?>
                                        <span class="badge badge-danger">Low Stock:<?php echo e($alertStock); ?></span>
                                        <?php else: ?>
                                        <span class="badge badge-success"><?php echo e($alertStock); ?></span>
                                        <?php endif; ?>
                                    <td>
                                        <div class="btn-group">
                                            <a href="#" class="btn btn-info btn-sm" data-toggle="modal" data-target="#editproduct<?php echo e($product->id); ?>">
                                                <i class="fa fa-edit"></i> Edit
                                            </a>
                                            <form action="<?php echo e(route('products.destroy', $product->id)); ?>" method="POST" style="display:inline;">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-danger btn-sm">
                                                    <i class="fa fa-trash"></i> Delete
                                                </button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>

                                <!-- Edit product Modal -->
                                <div class="modal right fade" id="editproduct<?php echo e($product->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                    <div class="modal-dialog" role="document">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h4 class="modal-title" id="exampleModalLabel">Edit product</h4>
                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                    <span aria-hidden="true">&times;</span>
                                                </button>
                                            </div>
                                            <div class="modal-body">
                                                <form action="<?php echo e(route('products.update', $product->id)); ?>" method="POST">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('PUT'); ?>
                                                    <div class="form-group">
                                                        <label for="name">Name</label>
                                                        <input type="text" name="name" id="name" value="<?php echo e($product->name); ?>" class="form-control">
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="email">Email</label>
                                                        <input type="email" name="email" id="email" value="<?php echo e($product->email); ?>" class="form-control">
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="password">Password</label>
                                                        <input type="password" name="password" id="password" class="form-control">
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="confirm_password">Confirm Password</label>
                                                        <input type="password" name="confirm_password" id="confirm_password" class="form-control">
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="role">Role</label>
                                                        <select name="is_admin" id="role" class="form-control">
                                                            <option value="1" <?php if($product->is_admin == 1): ?> selected <?php endif; ?>>Admin</option>
                                                            <option value="2" <?php if($product->is_admin == 2): ?> selected <?php endif; ?>>Cashier</option>
                                                        </select>
                                                    </div>
                                                    <div class="modal-footer justify-content-center">
                                                        <button class="btn btn-primary btn-block">Save product</button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <!-- Pagination links -->
                    <?php echo e($products->links()); ?>

                </div>
            </div>
        </div>
        <div class="col-lg-3">
            <div class="card">
                <div class="card-header">
                    <h4>Search product</h4>
                </div>
                <div class="card-body">
                    <!-- Your search form or content goes here -->
                    <form>
                        <div class="form-group">
                            <label for="searchInput">Search:</label>
                            <input type="text" class="form-control" id="searchInput" placeholder="Enter keyword">
                        </div>
                        <button type="submit" class="btn btn-primary">Search</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Add product Modal -->
<div class="modal right fade" id="addproduct" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title" id="exampleModalLabel">Add product</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form action="<?php echo e(route('products.store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="name">Product Name</label>
                        <input type="text" name="product_name" id="name" class="form-control">
                    </div>

                    <div class="form-group">
                        <label for="role">Brand</label>
                        <input type="text" name="brand" id="" class="form-control">
                    </div>

                    <div class="form-group">
                        <label for="price">Price</label>
                        <input type="number" name="price" id="price" class="form-control">
                    </div>

                    <div class="form-group">
                        <label for="stock">Alert Stock</label>
                        <input type="number" name="altert_stock" id="alertstock" class="form-control">
                    </div>
                    
                    <div class="form-group">
                        <label for="quantity">Quantity</label>
                        <input type="number" name="quantity" id="quantity" class="form-control">
                    </div>

                    <div class="form-group">
                        <label for="confirm_password">Description</label>
                        <textarea name="description" id="" cols="30" rows="2"class="form-control"></textarea>
                    </div>
                    
                    <div class="modal-footer justify-content-center">
                        <button class="btn btn-primary btn-block">Save Product</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<style>
    .modal.right .modal-dialog {
        top: 0;
        right: 0;
        margin-right: 15vh;
    }

    .modal.fade:not(.in).right .modal-dialog {
        -webkit-transform: translate3d(25%, 0, 0);
        transform: translate3d(25%, 0, 0);
    }
</style>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Sir Martin Njoroge\Desktop\laravel\resources\views\Products\index.blade.php ENDPATH**/ ?>