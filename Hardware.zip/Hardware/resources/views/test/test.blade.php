<!DOCTYPE html>
<html>
<head>
    <title>Test View</title>
</head>
<body>
    <h1>Order Details Test</h1>
    <table border="1">
        <tr>
            <th>Product Name</th>
            <th>Quantity</th>
            <th>Unit Price</th>
            <th>Discount</th>
            <th>Amount</th>
        </tr>
        @foreach ($order_details as $detail)
            <tr>
                <td>{{ $detail->product ? $detail->product->product_name : 'No product' }}</td>
                <td>{{ $detail->quantity }}</td>
                <td>{{ $detail->unitprice }}</td>
                <td>{{ $detail->discount ?? '0' }}</td>
                <td>{{ $detail->amount }}</td>
            </tr>
        @endforeach
    </table>
</body>
</html>
