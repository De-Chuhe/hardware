<div class="row">
    <div class="col-lg-8">
        <div class="card">
            <div class="card-header">
                <h4 style="float:left">Order Products</h4>
                <a href="#" style="float:right" class="btn btn-dark" data-toggle="modal" data-target="#addproduct">
                    <i class="fa fa-plus"></i> Add New Products
                </a>
            </div>
            <form action="{{ route('orders.store') }}" method="post">
                @csrf
                <div class="card-body">
                    <div class="my-2 ">
                        <form wire:submit.prevent="Inserttocart">
                            <input type="text" name="product_code" wire:model="product_code" id="" class="form-control" placeholder="Enter Product Code">
                        </form>                           
                    </div>
                    {{ $productIncart }}
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Product Name</th>
                                <th>Qty</th>
                                <th>Price</th>
                                <th>Disc %</th>
                                <th>Total</th>
                                <th><a href="#" class="btn btn-sm btn-success add_more rounded-circle"><i class="fa fa-plus"></i></a></th>
                            </tr>
                        </thead>
                        <tbody class="addMoreProduct">
                            @if($products)
                                @foreach($products as $product)
                                    <tr>
                                        <td>{{ $loop->iteration }}</td>
                                        <td>
                                            <select name="product_id[]" class="form-control product_id">
                                                <option value="{{ $product->id }}">{{ $product->product_name }}</option>
                                            </select>
                                        </td>
                                        <td>
                                            <input type="number" name="quantity[]" class="form-control quantity">
                                        </td>
                                        <td>
                                            <input type="number" name="price[]" class="form-control price" readonly>
                                        </td>
                                        <td>
                                            <input type="number" name="discount[]" class="form-control discount">
                                        </td>
                                        <td>
                                            <input type="number" name="total_amount[]" class="form-control total_amount" readonly>
                                        </td>
                                        <td><a href="#" class="btn btn-sm btn-danger delete rounded-circle"><i class="fa fa-times"></i></a></td>
                                    </tr>
                                @endforeach
                            @endif
                        </tbody>
                    </table>
                    {{ $products->links() }}
                </div>
            </form>
        </div>
    </div>
    <div class="col-lg-4">
        <div class="card">
            <div class="card-header">
                <h4>Total <b class="total">0.00</b></h4>
            </div>
            <div class="card-body">
                <div class="btn-group">
                    <button type="button" onclick="printReceipt()" class="btn btn-dark"><i class="fa fa-print"></i> Print</button>
                    <button type="button" class="btn btn-primary"><i class="fa fa-history"></i> History</button>
                    <button type="button" class="btn btn-danger"><i class="fa fa-file-alt"></i> Report</button>
                </div>
                <div class="panel">
                    <div class="row">
                        <table class="table table-striped">
                            <tr>
                                <td>
                                    <label for="">Customer Name</label>
                                    <input type="text" name="customer_name" class="form-control">
                                </td>
                                <td>
                                    <label for="">Customer Number</label>
                                    <input type="number" name="customer_number" class="form-control">
                                </td>
                            </tr>
                        </table>
                        <td>Payment Method <br>
                            <span class="radio-item">
                                <input type="radio" name="payment_method" value="cash" checked="checked">
                                <label><i class="fas fa-money-bill-alt text-success"></i>Cash</label>
                            </span>
                            <span class="radio-item">
                                <input type="radio" name="payment_method" value="bank_transfer">
                                <label><i class="fas fa-university text-danger"></i>Bank Transfer</label>
                            </span>
                            <span class="radio-item">
                                <input type="radio" name="payment_method" value="mpesa">
                                <label><i class="fas fa-mobile text-info"></i>M-PESA</label>
                            </span>
                        </td><br>
                        <td>
                            Payment
                                Payment
                                <input type="number" name="paid_amount" id="paid_amount" class="form-control">
                            </td>
                            <td>
                                Returning change
                                <input type="number" readonly name="balance" id="balance" class="form-control">
                            </td>
                            <td>
                                <button type="submit" class="btn-primary btn-lg btn-block mt-3">Save</button>
                            </td>
                            <td>
                                <button class="btn-danger btn-lg btn-block mt-2">Calculator</button>
                            </td>
                            <td>
                                <a href="#" style="text-align:center !important" class="text-danger"><i class="fa fa-sign-out-alt"></i> Log out</a>
                            </td>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Add product Modal -->
    <div class="modal right fade" id="addproduct" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title" id="exampleModalLabel">Add product</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form action="{{ route('products.store') }}" method="POST">
                        @csrf
                        <div class="form-group">
                            <label for="name">Product Name</label>
                            <input type="text" name="product_name" id="name" class="form-control">
                        </div>
                        <div class="form-group">
                            <label for="role">Brand</label>
                            <input type="text" name="brand" class="form-control">
                        </div>
                        <div class="form-group">
                            <label for="price">Price</label>
                            <input type="number" name="price" id="price" class="form-control">
                        </div>
                        <div class="form-group">
                            <label for="stock">Alert Stock</label>
                            <input type="number" name="alert_stock" id="alertstock" class="form-control">
                        </div>
                        <div class="form-group">
                            <label for="quantity">Quantity</label>
                            <input type="number" name="quantity" id="quantity" class="form-control">
                        </div>
                        <div class="form-group">
                            <label for="description">Description</label>
                            <textarea name="description" cols="30" rows="2" class="form-control"></textarea>
                        </div>
                        <div class="modal-footer justify-content-center">
                            <button class="btn btn-primary btn-block">Save Product</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
